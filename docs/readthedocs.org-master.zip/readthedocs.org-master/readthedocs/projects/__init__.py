default_app_config = 'readthedocs.projects.apps.ProjectsConfig'
