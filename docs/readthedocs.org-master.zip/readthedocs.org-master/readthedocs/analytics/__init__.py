"""App init"""

default_app_config = 'readthedocs.analytics.apps.AnalyticsAppConfig'    # noqa
