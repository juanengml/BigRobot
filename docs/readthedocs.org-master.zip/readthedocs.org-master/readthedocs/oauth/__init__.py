default_app_config = 'readthedocs.oauth.apps.OAuthConfig'
