"""Django app configuration for the notifications app."""
from __future__ import absolute_import
from django.apps import AppConfig


class NotificationsAppConfig(AppConfig):
    name = 'readthedocs.notifications'
    verbose_name = 'Notifications'
